package com.better.learn.androidx;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * https://developer.android.com/jetpack/androidx
 * https://developer.android.com/jetpack/androidx/releases/archive/androidx#1.0.0a1-ki
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
